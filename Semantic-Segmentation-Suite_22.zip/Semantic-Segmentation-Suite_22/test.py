#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed May  2 14:31:26 2018

@author: family
"""


import numpy as np


rc = 6
cc = 4
A = np.random.rand(4,6,3)
a = A.copy()
if ((rc <= A.shape[0]) and (cc <= A.shape[1])):
    print(1)
else:
    if (rc > A.shape[0]):
        print(21)
        diff = (rc - A.shape[0])
        print('diff', diff)
        padl = diff//2
        padr = diff - padl
        print('padl', padl)
        print('padr', padr)
        
        #A = np.pad(A, (padl,padr, 0),'constant', constant_values=(0, 0, 0))[:, padl:-padr, :]
        A = np.pad(A, (padl, padr),'constant', constant_values=(0, 0))
        
    if (cc > A.shape[1]):
        print(22)
        diff = (cc - A.shape[1])
        print('diff', diff)
        padu = diff//2
        padd = diff - padu
        print('padu', padu)
        print('padd', padd)
        
        #A = np.pad(A, (padu,padd,0),'constant', constant_values=(0,0,0))[padu:-padd,:]






