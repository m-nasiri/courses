#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Apr 14 11:52:27 2018

@author: family
"""

import numpy as np
import tensorflow as tf

def compute_mean_iou(pred, label):

    unique_labels = np.unique(label)
    num_unique_labels = len(unique_labels);

    I = np.zeros(num_unique_labels)
    U = np.zeros(num_unique_labels)

    for index, val in enumerate(unique_labels):
        pred_i = pred == val
        label_i = label == val

        I[index] = float(np.sum(np.logical_and(label_i, pred_i)))
        U[index] = float(np.sum(np.logical_or(label_i, pred_i)))


    mean_iou = np.mean(I / U)
    return mean_iou



label = np.array([-1,-1,-1,0,0,0,1,1,1])
pred  = np.array([-1,-1,-1,0,0,0,0,1,1])

print(compute_mean_iou(pred=pred, label=label))




n_classes = tf.constant(3, shape=[1])
labels = pred
predictions = label
accuracy, update_op_acc = tf.contrib.metrics.streaming_accuracy(labels,
                                                                predictions)


error, update_op_error = tf.contrib.metrics.streaming_mean_iou(predictions=predictions,
                                                               labels=labels,
                                                               num_classes=n_classes)

sess = tf.Session()
sess.run(tf.local_variables_initializer())
sess.run([update_op_acc, update_op_error])

accuracy, mean_absolute_error = sess.run([accuracy, error])

print(accuracy, mean_absolute_error)







