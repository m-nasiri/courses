#-----------------------------------------------------------------------------#
# coder: Majid Nasiri
# github: https://github.com/m-nasiri/tensorflow
# date: 2017-December-03
#-----------------------------------------------------------------------------#


from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
from utils import ImageReader, decode_labels, inv_preprocess, prepare_label
import shutil
import os

n_train = 60000
n_test = 10000
n_classes = 10 + 1 # 0 ~ 9 + void

log_dir = './logs/model'
if os.path.exists(log_dir):
    shutil.rmtree(log_dir)

data_dir = './dataset'
data_list = './dataset/train_list.txt'
input_size = None #(28, 28)
random_scale = False
random_mirror = False
ignore_label = 255
IMG_MEAN = np.array((0.0, 0.0, 0.0), dtype=np.float32)

# Network Parameters
kf1, nf1 = 3, 12
kf2, nf2 = 3, 24
kf3, nf3 = 3, 32
kf4, nf4 = 3, n_classes

# Training Parameters
starter_learning_rate = 0.001
batch_size = 128
display_step = 10
n_epochs = 100
n_itrs = n_train//batch_size
weight_decay = 0.0001
momentum = 0.9
power = 0.9


# turn off interactive mode
plt.ioff()

tf.reset_default_graph()
graph = tf.Graph()
with graph.as_default():

    # define polynomial decay function
    # 'poly' learning rate
    base_lr = tf.constant(starter_learning_rate)
    curr_step = tf.placeholder(dtype=tf.float32, shape=())
    learning_rate = tf.scalar_mul(base_lr, tf.pow((1 - curr_step / n_epochs), power))

    tf.summary.scalar("learning_rate", learning_rate)


    # define placeholder for input images
    X = tf.placeholder(tf.float32, shape=[None, 28, 28, 1])

    # Encoder - Transforming image space to feature space
    with tf.name_scope('encoder') as scope:
        # Convolution Layer 1
        with tf.name_scope('conv1') as scope:
            weights = tf.Variable(tf.truncated_normal([kf1, kf1, 1, nf1], mean=0.0, stddev=0.1), name='weights')
            biases = tf.Variable(tf.constant(0.1, shape=[nf1]), name='biases')
            conv = tf.nn.conv2d(X, weights, strides=[1, 1, 1, 1], padding='SAME')
            conv = tf.nn.bias_add(conv, biases)
            conv = tf.contrib.layers.batch_norm(conv,
                                                scale=True,
                                                activation_fn=tf.nn.relu,
                                                is_training=False,
                                                trainable=False,
                                                scope=scope +'/BatchNorm')

            relu = tf.nn.relu(conv , name=scope)
            #pool = tf.nn.max_pool(relu, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME')
            tf.summary.histogram("conv", conv)
            tf.summary.histogram("relu", relu)

        # Convolution Layer 2
        with tf.name_scope('conv2') as scope:
            weights = tf.Variable(tf.truncated_normal([kf2, kf2, nf1, nf2], mean=0.0, stddev=0.1), name='weights')
            biases = tf.Variable(tf.constant(0.1, shape=[nf2]), name='biases')
            conv = tf.nn.conv2d(relu, weights, strides=[1, 1, 1, 1], padding='SAME')
            conv = tf.nn.bias_add(conv, biases)
            conv = tf.contrib.layers.batch_norm(conv,
                                                scale=True,
                                                activation_fn=tf.nn.relu,
                                                is_training=False,
                                                trainable=False,
                                                scope=scope +'/BatchNorm')

            relu = tf.nn.relu(conv , name=scope)
            #pool = tf.nn.max_pool(conv, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME')
            tf.summary.histogram("conv", conv)
            tf.summary.histogram("relu", relu)

        # Convolution Layer 3
        with tf.name_scope('conv3') as scope:
            weights = tf.Variable(tf.truncated_normal([kf3, kf3, nf2, nf3], mean=0.0, stddev=0.1), name='weights')
            biases = tf.Variable(tf.constant(0.1, shape=[nf3]), name='biases')
            conv = tf.nn.conv2d(relu, weights, strides=[1, 1, 1, 1], padding='SAME')
            #conv = tf.nn.atrous_conv2d(pool, weights, rate=2, padding='SAME')
            conv = tf.nn.bias_add(conv, biases)
            conv = tf.contrib.layers.batch_norm(conv,
                                                scale=True,
                                                activation_fn=tf.nn.relu,
                                                is_training=False,
                                                trainable=False,
                                                scope=scope +'/BatchNorm')

            relu = tf.nn.relu(conv , name=scope)
            tf.summary.histogram("conv", conv)
            tf.summary.histogram("relu", relu)

    # Decoder - Transforming feature space to image space
    with tf.name_scope('decoder') as scope:
        # Unpooling & Convolution Layer 1
        with tf.name_scope('conv1') as scope:
            weights = tf.Variable(tf.truncated_normal([kf4, kf4, nf3, nf4], mean=0.0, stddev=0.1), name='weights')
            biases = tf.Variable(tf.constant(0.1, shape=[nf4]), name='biases')
            conv = tf.nn.conv2d(relu, weights, strides=[1, 1, 1, 1], padding='SAME')
            #conv = tf.nn.atrous_conv2d(conv, weights, rate=2, padding='SAME')
            conv = tf.nn.bias_add(conv, biases)
            logits = tf.nn.sigmoid(conv)

            tf.summary.histogram("conv", conv)
            tf.summary.histogram("logits", logits)



    coord = tf.train.Coordinator()
    reader = ImageReader(data_dir,
                         data_list,
                         input_size,
                         random_scale,
                         random_mirror,
                         ignore_label,
                         IMG_MEAN,
                         coord)

    image_batch, label_batch = reader.dequeue(batch_size)
    print("image_batch -------------", image_batch.shape)
    print("label_batch -------------", label_batch.shape)

    # Network raw output
    # [batch_size, h, w, 21]
    # raw_output [b, 14, 14, 1]
    raw_output = logits
    print('raw_output --------------', raw_output.shape)
    # Processed predictions: for visualisation.
    # raw_output [b, 14, 14, 1] --> raw_output_up [b, 28, 28, 1]
    raw_output_up = tf.image.resize_bilinear(raw_output, (28, 28))
    # raw_output_up [b, 28, 28, 1] --> raw_output_argmax [b, 28, 28]
    raw_output_argmax = tf.argmax(raw_output_up, axis=3)
    print('raw_output_argmax -------', raw_output_argmax.shape)
    # raw_output_argmax [b, 28, 28] --> pred [b, 28, 28, 1]
    pred = tf.expand_dims(raw_output_argmax, dim=3)
    print('pred --------------------', pred.shape)


    output_shape = tf.shape(raw_output)
    output_size = (output_shape[1], output_shape[2])

    # Groud Truth: prepare labels
    # as labels are integer numbers, need to use NN interp.
    # label_batch (b , 28, 28, 1) --> (b, 14, 14, 1)
    label_batch_resized = tf.image.resize_nearest_neighbor(label_batch, output_size)
    print('label_batch_resized -----', label_batch_resized.shape)
    # reducing the channel dimension.
    # label_batch (b , 14, 14, 1) --> (b, 14, 14)
    label_batch_resized = tf.squeeze(label_batch_resized, squeeze_dims=[3])
    # label_batch (b , 14, 14) --> (b, 14, 14, 11)
    label_batch_onehot = tf.one_hot(label_batch_resized, depth=n_classes)
    print('label_batch_onehot ------' , label_batch_onehot.shape)


    with tf.name_scope('loss') as scope:
        # Pixel-wise softmax_cross_entropy loss
        loss = label_batch_onehot * tf.log(logits + 1E-8)
        loss += (1-label_batch_onehot) * tf.log(1-logits + 1E-8)
        loss = -tf.reduce_mean(loss) #+ tf.add_n(l2_losses)
        tf.summary.scalar("loss", loss)

    with tf.name_scope('optimizer') as scope:
        # define training step which minimises cross entropy
        optimizer = tf.train.GradientDescentOptimizer(learning_rate=learning_rate)
        optimizer = optimizer.minimize(loss)


    # Image summary.
    images_summary = tf.py_func(inv_preprocess, [image_batch, 4, IMG_MEAN], tf.uint8)
    labels_summary = tf.py_func(decode_labels, [label_batch, 4, n_classes], tf.uint8)
    preds_summary = tf.py_func(decode_labels, [pred, 4, n_classes], tf.uint8)
    tf.summary.image('images', images_summary)
    tf.summary.image('labels', labels_summary)
    tf.summary.image('preds', preds_summary)


    merged_summary = tf.summary.merge_all()

# Create a session for running operations in the Graph.
with tf.Session(graph=graph) as sess:

    # Initialize the variables (the trained variables and the epoch counter).
    sess.run(tf.global_variables_initializer())

    # Start queue threads.
    threads = tf.train.start_queue_runners(coord=coord, sess=sess)

    writer = tf.summary.FileWriter(log_dir)
    writer.add_graph(sess.graph)

    saver = tf.train.Saver(max_to_keep=100)

    #n_epochs = 1
    #n_itrs = 1
    for epoch in range(n_epochs): # n_epochs
        for itr in range(n_itrs): #n_itrs

            # fetch the batch train images
            batch_x, batch_y = sess.run([image_batch, label_batch])
#            print(np.max(batch_x), np.min(batch_x))
#            print(np.max(batch_y), np.min(batch_y))
            feed_dict={X: batch_x, curr_step: epoch}

            sess.run(optimizer, feed_dict=feed_dict)
            loss_val, t1, t2 = sess.run([loss, label_batch, label_batch_resized], feed_dict=feed_dict)
            #print(loss_val.min(), loss_val.max())
            #print(t1.min(), t1.max())
            #print(t1.shape, t2.shape)


            # evaluate train batch loss
            if ((itr+1) % display_step == 0):
                loss_val, summary = sess.run([loss, merged_summary], feed_dict={X: batch_x, curr_step: epoch})
                summary_step = int(epoch*n_itrs + itr)
                writer.add_summary(summary, summary_step)
                print('epoch=%d itr=%d/%d  minibach_loss=%1.5f' % (epoch ,itr, n_itrs, loss_val))


        saver.save(sess=sess, save_path=log_dir, global_step=epoch)

    coord.request_stop()
    coord.join(threads)

