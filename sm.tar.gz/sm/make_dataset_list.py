#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr  2 23:25:18 2018

@author: family
"""

n_train = 60000
f = open("./dataset/train_list.txt","w+")
for i in range(n_train):
     f.write("/train/images/image_%d.png /train/labels/label_%d.png\n" % (i, i))
f.close()



