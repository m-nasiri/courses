#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr  2 01:29:09 2018

@author: family
"""

import numpy as np
from PIL import Image

mnist_file = '../../../Dataset/MNIST/mnist.npz'
dataset = np.load(mnist_file)

train_x = dataset['x_train']
train_y = dataset['y_train']
test_x = dataset['x_test']
test_y = dataset['y_test']

n_train = train_x.shape[0]
n_test = test_x.shape[0]


for i in range(n_test):
    im = Image.fromarray(test_x[i,:,:])
    im.save('./dataset/test/image_'+str(i)+'.png')

for i in range(n_test):
    x = test_x[i,:,:]
    x [x>0] = test_y[i] + 1
    im = Image.fromarray(x)
    im.save('./dataset/test/labels/label_'+str(i)+'.png')


for i in range(n_train):
    im = Image.fromarray(train_x[i,:,:])
    im.save('./dataset/train/images/image_' + str(i) + '.png')

for i in range(n_train):
    x = train_x[i,:,:]
    x [x>0] = train_y[i] + 1
    im = Image.fromarray(x)
    im.save('./dataset/train/labels/label_'+str(i)+'.png')



