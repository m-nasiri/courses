
from datetime import datetime
import os
import sys
import time
import numpy as np
import tensorflow as tf
from PIL import Image

from network import *
from network import ResNet_segmentation
#from utils import ImageReader, decode_labels, inv_preprocess, prepare_label, write_log, read_labeled_image_list



"""
This script trains or evaluates the model on augmented PASCAL VOC 2012 dataset.
The training set contains 10581 training images.
The validation set contains 1449 validation images.

Training:
'poly' learning rate
different learning rates for different layers
"""



IMG_MEAN = np.array((104.00698793,116.66876762,122.67891434), dtype=np.float32)

class Model(object):
    def __init__(self, sess, conf):
        self.sess = sess
        self.conf = conf

    # train
    def train(self):
        self.train_setup()

        self.sess.run(tf.global_variables_initializer())

        # Load the pre-trained model if provided
        if self.conf.pretrain_file is not None:
            self.load(self.loader, self.conf.pretrain_file)

        # Train!
        for step in range(self.conf.num_steps+1):
            start_time = time.time()
            feed_dict = {self.curr_step : step,
                         self.image_batch : np.random.random(size=[self.conf.batch_size,
                                                                   self.conf.input_height, 
                                                                   self.conf.input_width,
                                                                   3]), 
                         self.label_batch : np.random.random(size=[self.conf.batch_size,
                                                                   self.conf.num_classes])}
            loss_value, images, labels, preds, summary, _ = self.sess.run([self.reduced_loss,
                                                                           self.pred,
                                                                           self.total_summary,
                                                                           self.train_op],
                                                                          feed_dict=feed_dict)

            self.summary_writer.add_summary(summary, step)
            self.save(self.saver, step)


            duration = time.time() - start_time
            print('step {:d} \t loss = {:.3f}, ({:.3f} sec/step)'.format(step, loss_value, duration))
            write_log('{:d}, {:.3f}'.format(step, loss_value), self.conf.logfile)

        self.images = images
        self.labels = labels
        self.preds = preds

#-----------------------------------------------------------------------------#
#-----------------------------------------------------------------------------#
#-----------------------------------------------------------------------------#
    def train_setup(self):

        tf.set_random_seed(self.conf.random_seed)

        # Create network
        if self.conf.encoder_name not in ['res101', 'res50']:
            print('encoder_name ERROR!')
            print("Please input: res101 or res50")
            sys.exit(-1)

        else:
            
            self.image_batch = tf.placeholder('float', shape=[10, 224, 224, 3], name='resnet_input')
            self.label_batch = tf.placeholder('float', shape=[10, 40], name='resnet_output')
            
            net = ResNet_segmentation(self.image_batch, self.conf.num_classes, True, self.conf.encoder_name)
            # Variables that load from pre-trained model.
            restore_var = [v for v in tf.global_variables() if 'resnet_v1' in v.name]
            # Trainable Variables
            all_trainable = tf.trainable_variables()
            # Fine-tune part
            encoder_trainable = [v for v in all_trainable if 'resnet_v1' in v.name] # lr * 1.0
            # Decoder part
            classifier_trainable = [v for v in all_trainable if 'classifier' in v.name]
            #print('classifier_trainable', classifier_trainable)

        classifier_w_trainable = [v for v in classifier_trainable if 'weights' in v.name or 'gamma' in v.name]  # lr * 10.0
        classifier_b_trainable = [v for v in classifier_trainable if 'biases' in v.name or 'beta' in v.name]    # lr * 20.0
        
        # Check
        assert(len(all_trainable) == len(classifier_trainable) + len(encoder_trainable))
        assert(len(classifier_trainable) == len(classifier_w_trainable) + len(classifier_b_trainable))

        # Network raw output
        logits = net.outputs    # [batch_size, 40]
        gt = self.label_batch
        
        # Pixel-wise softmax_cross_entropy loss
        loss = tf.nn.softmax_cross_entropy_with_logits(logits=logits, labels=gt)
 
        # L2 regularization
        l2_losses = [self.conf.weight_decay * tf.nn.l2_loss(v) for v in all_trainable if 'weights' in v.name]

        # Loss function
        self.reduced_loss = tf.reduce_mean(loss) + tf.add_n(l2_losses)

        # Define optimizers
        # 'poly' learning rate
        base_lr = tf.constant(self.conf.learning_rate)
        self.curr_step = tf.placeholder(dtype=tf.float32, shape=())
        learning_rate = tf.scalar_mul(base_lr, tf.pow((1 - self.curr_step / self.conf.num_steps), self.conf.power))
        # We have several optimizers here in order to handle the different lr_mult
        # which is a kind of parameters in Caffe. This controls the actual lr for each
        # layer.
        
        opt_encoder = tf.train.MomentumOptimizer(learning_rate, self.conf.momentum)
        opt_classifier_w = tf.train.MomentumOptimizer(learning_rate * 10.0, self.conf.momentum)
        opt_classifier_b = tf.train.MomentumOptimizer(learning_rate * 20.0, self.conf.momentum)
        
        # To make sure each layer gets updated by different lr's, we do not use 'minimize' here.
        # Instead, we separate the steps compute_grads+update_params.
        # Compute grads
        grads = tf.gradients(self.reduced_loss, encoder_trainable + classifier_w_trainable + classifier_b_trainable)
        grads_encoder = grads[:len(encoder_trainable)]
        grads_decoder_w = grads[len(encoder_trainable) : (len(encoder_trainable) + len(classifier_w_trainable))]
        grads_decoder_b = grads[(len(encoder_trainable) + len(classifier_w_trainable)):]
        
        # Update params
        train_op_conv = opt_encoder.apply_gradients(zip(grads_encoder, encoder_trainable))
        train_op_fc_w = opt_classifier_w.apply_gradients(zip(grads_decoder_w, classifier_w_trainable))
        train_op_fc_b = opt_classifier_b.apply_gradients(zip(grads_decoder_b, classifier_b_trainable))
        
        # Finally, get the train_op!
        update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS) # for collecting moving_mean and moving_variance
        with tf.control_dependencies(update_ops):
            self.train_op = tf.group(train_op_conv, train_op_fc_w, train_op_fc_b)

        # Saver for storing checkpoints of the model
        self.saver = tf.train.Saver(var_list=tf.global_variables(), max_to_keep=0)

        # Loader for loading the pre-trained model
        self.loader = tf.train.Saver(var_list=restore_var)

#-----------------------------------------------------------------------------#
#-----------------------------------------------------------------------------#
#-----------------------------------------------------------------------------#
    def save(self, saver, step):
        '''
        Save weights.
        '''
        model_name = 'model.ckpt'
        checkpoint_path = os.path.join(self.conf.modeldir, model_name)
        if not os.path.exists(self.conf.modeldir):
            os.makedirs(self.conf.modeldir)
            saver.save(self.sess, checkpoint_path, global_step=step)
            print('The checkpoint has been created.')

#-----------------------------------------------------------------------------#
#-----------------------------------------------------------------------------#
#-----------------------------------------------------------------------------#
    def load(self, saver, filename):
        '''
        Load trained weights.
        '''
        saver.restore(self.sess, filename)
        print("Restored model parameters from {}".format(filename))
