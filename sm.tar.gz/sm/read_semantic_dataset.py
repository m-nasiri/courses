#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr  2 01:29:09 2018

@author: family
"""

import numpy as np
import tensorflow as tf
from image_reader import ImageReader


data_dir = './dataset'
data_list = './dataset/train_list.txt'
input_size = None #(28, 28)
random_scale = False
random_mirror = False
ignore_label = 255
IMG_MEAN = np.array((0.0, 0.0, 0.0), dtype=np.float32)
batch_size = 4



tf.reset_default_graph()
sess = tf.Session()

coord = tf.train.Coordinator()
reader = ImageReader(data_dir,
                     data_list,
                     input_size,
                     random_scale,
                     random_mirror,
                     ignore_label,
                     IMG_MEAN,
                     coord)

image_batch, label_batch = reader.dequeue(batch_size)


sess.run(tf.global_variables_initializer())

# Start queue threads.
threads = tf.train.start_queue_runners(coord=coord, sess=sess)

batch_x, batch_y = sess.run([image_batch, label_batch])
print(np.max(batch_x), np.min(batch_x))
print(np.max(batch_y), np.min(batch_y))


coord.request_stop()
coord.join(threads)


sess.close()







