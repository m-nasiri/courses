#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed May  2 14:31:26 2018

@author: family
"""


import numpy as np


rc = 9
cc = 8
A = np.random.rand(4,6,3)
r, c, d = A.shape
a = A.copy()
if ((rc <= A.shape[0]) and (cc <= A.shape[1])):
    print(1)
else:
    if (rc > r):
        print(21)
        diff = (rc - r)
        print('diff', diff)
        padu = diff//2
        padd = diff - padu
        print('padu', padu)
        print('padd', padd)
        
        up = np.zeros((padu,c,d))
        down = np.zeros((padd,c,d))
        A = np.concatenate((up, A, down), axis=0)
        print(up.shape)
        print(A.shape)
        print(down.shape)
        print(A.shape)
        r = rc
                
    if (cc > c):
        print(22)
        diff = (cc - c)
        print('diff', diff)
        padl = diff//2
        padr = diff - padl
        print('padl', padl)
        print('padr', padr)
        
        left = np.zeros((r,padl,d))
        right = np.zeros((r,padr,d))
        A = np.concatenate((left, A, right), axis=1)        






